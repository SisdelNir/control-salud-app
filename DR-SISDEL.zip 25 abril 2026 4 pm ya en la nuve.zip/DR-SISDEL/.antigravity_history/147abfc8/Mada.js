document.addEventListener('DOMContentLoaded', () => {
    const qslForm = document.getElementById('qsl-form');
    const qslInput = document.getElementById('qsl-code');
    const submitBtn = document.getElementById('submit-btn');
    const toastContainer = document.getElementById('toast-container');
    const roleBtns = document.querySelectorAll('.role-btn');
    const inputLabel = document.getElementById('input-label');

    let currentRole = 'paciente';

    // Manejo de Roles
    roleBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            roleBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentRole = btn.dataset.role;

            // Cambiar textos según rol
            if (currentRole === 'medico') {
                inputLabel.textContent = 'CÓDIGO DE IDENTIFICACIÓN MÉDICA';
                qslInput.placeholder = 'Ingrese su ID profesional...';
            } else {
                inputLabel.textContent = 'CÓDIGO QSL DE PACIENTE';
                qslInput.placeholder = 'Ingrese el código...';
            }
        });
    });

    // Cargar sesión previa
    const savedCode = localStorage.getItem('user_qsl_code');
    const savedRole = localStorage.getItem('user_role');
    const savedName = localStorage.getItem('user_real_name');

    if (savedCode && savedRole) {
        qslInput.value = savedCode;
        if (savedName) document.getElementById('user-name').value = savedName;
    }

    qslForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const code = qslInput.value.trim().toUpperCase();
        const name = document.getElementById('user-name').value.trim();

        if (code.length < 3) {
            showToast('Identificación demasiado corta', 'error');
            return;
        }

        // Guardar sesión
        localStorage.setItem('user_qsl_code', code);
        localStorage.setItem('user_role', currentRole);
        localStorage.setItem('user_real_name', name);

        // Vincular nombre al QSL si es paciente
        if (currentRole === 'paciente') {
            localStorage.setItem(`patient_name_${code}`, name);
        } else if (currentRole === 'medico') {
            localStorage.setItem(`doctor_name_${code}`, name);
        }

        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span>Iniciando...</span>';

        setTimeout(() => {
            showToast(`Bienvenido ${name || currentRole}`, 'success');
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 800);
        }, 800);
    });

    function showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <span>${message}</span>
        `;
        toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(50px)';
            setTimeout(() => toast.remove(), 500);
        }, 3000);
    }

    // Efecto de brillo en el input al escribir
    qslInput.addEventListener('input', (e) => {
        if (e.target.value.length > 0) {
            e.target.style.boxShadow = '0 0 15px rgba(79, 70, 229, 0.2)';
        } else {
            e.target.style.boxShadow = 'none';
        }
    });
});
