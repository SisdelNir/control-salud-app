document.addEventListener('DOMContentLoaded', () => {
    const qslForm = document.getElementById('qsl-form');
    const qslInput = document.getElementById('qsl-code');
    const submitBtn = document.getElementById('submit-btn');
    const toastContainer = document.getElementById('toast-container');

    // Cargar código previo si existe
    const savedCode = localStorage.getItem('user_qsl_code');
    if (savedCode) {
        qslInput.value = savedCode;
    }

    qslForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const code = qslInput.value.trim();

        if (code.length < 5) {
            showToast('El código debe tener al menos 5 caracteres', 'error');
            return;
        }

        // Guardar el código para la sesión
        localStorage.setItem('user_qsl_code', code);
        
        // Animación de carga en el botón
        submitBtn.disabled = true;
        const originalContent = submitBtn.innerHTML;
        submitBtn.innerHTML = '<span>Verificando...</span>';

        // Simular validación y redirección
        setTimeout(() => {
            showToast('Acceso concedido. Redirigiendo...', 'success');
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1000);
        }, 800);
    });

    function showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <span>${message}</span>
        `;
        toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(50px)';
            setTimeout(() => toast.remove(), 500);
        }, 3000);
    }

    // Efecto de brillo en el input al escribir
    qslInput.addEventListener('input', (e) => {
        if (e.target.value.length > 0) {
            e.target.style.boxShadow = '0 0 15px rgba(79, 70, 229, 0.2)';
        } else {
            e.target.style.boxShadow = 'none';
        }
    });
});
