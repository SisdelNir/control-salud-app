# Medication Reminder Application

A premium, modern mobile-first web application to manage and schedule patient medications.

## Goal Description
Create a web application that acts as a medication tracker and alarm system. It allows scheduling multiple medications (name and dose) within a 24-hour cycle, extrapolating the schedule for up to three months. When it's time to take a medication, the app will trigger an alert. The application will be built using React and styled with a rich, dynamic Vanilla CSS design system that ensures a premium mobile experience.

## User Review Required
> [!IMPORTANT]  
> 1. **Alert Mechanism**: Standard web push notifications require user permission. On iOS, they only work if the user adds the web app to their home screen. For immediate functionality, I will implement a prominent in-app visual/audio alert system that works when the app is open, alongside standard browser notifications. Is this acceptable?
> 2. **Data Storage**: I plan to use the browser's Local Storage to save the medication schedules. This means the data stays on the patient's device and doesn't require cloud login. Is this okay?

## Proposed Changes

### Project Initialization
- Initialize a React project using Vite.

### Core Components
#### [NEW] `src/index.css`
Establish a custom design system focusing on aesthetics: vibrant colors/gradients, smooth micro-animations, glassmorphism UI elements, and a clean mobile-first layout.

#### [NEW] `src/App.jsx`
Main layout, routing (if necessary, or simple state-based views), and global state for schedules.

#### [NEW] `src/components/MedicationForm.jsx`
A form allowing the user to add a medication, specifying:
- Name
- Dose
- Times per day (or specific hours)
- Duration (up to 3 months)

#### [NEW] `src/components/Timeline.jsx`
A vertical timeline view showing today's medication schedule, indicating which doses have been taken or missed.

#### [NEW] `src/components/NotificationManager.jsx`
A background component that checks the current time against the schedule every minute and triggers an alert modal/browser notification.

## Verification Plan
### Automated Tests
- N/A for this rapid prototype.

### Manual Verification
- Run the Vite development server.
- Add a test medication scheduled 1 minute into the future.
- Verify the alert appears accurately with the correct name and dose.
- Add a 3-month schedule and verify the extrapolation logic.
