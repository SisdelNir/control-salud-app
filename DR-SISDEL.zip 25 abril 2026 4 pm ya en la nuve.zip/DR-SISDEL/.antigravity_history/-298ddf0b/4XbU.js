document.addEventListener('DOMContentLoaded', () => {
    // 1. Verificar Acceso y Rol
    const qslCode = localStorage.getItem('user_qsl_code');
    const userRole = localStorage.getItem('user_role');

    if (!qslCode || !userRole) {
        window.location.href = 'index.html';
        return;
    }

    // 2. Referencias UI
    const qslDisplay = document.getElementById('display-qsl');
    const logoutBtn = document.getElementById('logout-btn');
    const contentArea = document.getElementById('content-area');
    const sectionTitle = document.getElementById('section-title');
    const navItems = document.querySelectorAll('.nav-links li[data-section]');
    const dateDisplay = document.getElementById('current-date');

    // Estado local para médicos (Paciente seleccionado)
    let selectedPatientQSL = userRole === 'paciente' ? qslCode : null;

    // 3. Inicialización
    qslDisplay.textContent = userRole === 'medico' ? `Dr. ${qslCode}` : `QSL: ${qslCode}`;
    updateDate();
    loadSection('overview');

    // 4. Manejo de Navegación
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            loadSection(section);
        });
    });

    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('user_qsl_code');
        localStorage.removeItem('user_role');
        window.location.href = 'index.html';
    });

    // 5. Motor de Datos (Vinculado al QSL del Paciente)
    function getStorageKey(suffix) {
        return `health_${selectedPatientQSL}_${suffix}`;
    }

    function getMedications() {
        if (!selectedPatientQSL) return [];
        const meds = localStorage.getItem(getStorageKey('meds'));
        return meds ? JSON.parse(meds) : [];
    }

    function saveMedication(med) {
        const meds = getMedications();
        meds.push({ ...med, id: Date.now() });
        localStorage.setItem(getStorageKey('meds'), JSON.stringify(meds));
    }

    // 6. Motor de Secciones
    function loadSection(sectionName) {
        sectionTitle.textContent = getSectionTitle(sectionName);
        contentArea.innerHTML = `<div class="loading-state"><div class="spinner"></div></div>`;
        setTimeout(() => renderSection(sectionName), 300);
    }

    function renderSection(name) {
        // VISTA MÉDICO: Selección de Paciente si no hay uno
        if (userRole === 'medico' && !selectedPatientQSL && name !== 'settings') {
            renderPatientSearch();
            return;
        }

        const medications = getMedications();

        switch (name) {
            case 'overview':
                renderOverview(medications);
                break;

            case 'medications':
                renderMedications(medications);
                break;

            case 'reminders':
                renderReminders();
                break;

            case 'settings':
                renderSettings();
                break;
        }
    }

    // --- FUNCIONES DE RENDERIZADO ---

    function renderPatientSearch() {
        contentArea.innerHTML = `
            <div class="widget-card animate-in" style="max-width: 500px; margin: 0 auto; text-align: center;">
                <h3 class="widget-title">Panel de Control Médico</h3>
                <p style="margin-bottom: 25px; color: var(--text-muted)">Ingrese el Código QSL del paciente para ver su expediente.</p>
                <div class="input-group" style="margin-bottom: 20px;">
                    <input type="text" id="search-qsl" placeholder="Ej: QSL-789-XYZ">
                </div>
                <button id="btn-search-patient" class="btn-primary" style="width: 100%">Abrir Expediente</button>
            </div>
        `;
        document.getElementById('btn-search-patient').onclick = () => {
            const qsl = document.getElementById('search-qsl').value.trim();
            if (qsl) {
                selectedPatientQSL = qsl;
                loadSection('overview');
            }
        };
    }

    function renderOverview(meds) {
        const pendingMeds = meds.slice(0, 3);
        contentArea.innerHTML = `
            <div class="dashboard-grid">
                <div class="widget-card animate-in">
                    <h3 class="widget-title">
                        ${userRole === 'medico' ? `Expediente: ${selectedPatientQSL}` : `Mi Resumen`}
                    </h3>
                    ${userRole === 'medico' ? '<p style="color:var(--accent); font-size:12px; margin-bottom:15px">Modo Edición Habilitado</p>' : ''}
                    <h4 style="margin-bottom: 10px; font-size: 14px;">Próximas Tomas</h4>
                    <ul class="med-list">
                        ${pendingMeds.length > 0 ? pendingMeds.map(m => `
                            <li class="med-item">
                                <div class="med-info">
                                    <h4>${m.name}</h4>
                                    <p>${m.dose}</p>
                                </div>
                                <span class="status-badge">Activo</span>
                            </li>
                        `).join('') : '<p style="color: var(--text-muted); font-size: 13px;">Sin registros.</p>'}
                    </ul>
                </div>
                ${userRole === 'medico' ? `
                <div class="widget-card animate-in" style="animation-delay: 0.1s">
                    <h3 class="widget-title">Acciones Médicas</h3>
                    <button class="btn-primary" style="width:100%; margin-bottom:10px" onclick="selectedPatientQSL=null; loadSection('overview')">Cambiar de Paciente</button>
                    <button class="btn-primary" style="width:100%; background:rgba(255,255,255,0.05); color:var(--text-main)" onclick="alert('Historial generado')">Descargar PDF</button>
                </div>` : ''}
            </div>
        `;
    }

    function renderMedications(meds) {
        contentArea.innerHTML = `
            <div class="widget-card animate-in">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h3 class="widget-title">Medicamentos: ${selectedPatientQSL}</h3>
                    <button id="add-med-btn" class="btn-primary" style="padding: 8px 16px; font-size: 13px; margin: 0;">+ Agregar</button>
                </div>
                
                <div id="med-form-container" style="display: none; margin-bottom: 30px; padding: 20px; background: rgba(0,0,0,0.2); border-radius: 15px;">
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label>Nombre del Medicamento</label>
                        <input type="text" id="new-med-name" placeholder="Ej: Paracetamol">
                    </div>
                    <div class="input-group" style="margin-bottom: 15px;">
                        <label>Dosis / Frecuencia</label>
                        <input type="text" id="new-med-dose" placeholder="Ej: 500mg cada 8h">
                    </div>
                    <button id="save-med-btn" class="btn-primary" style="width: 100%;">Guardar Registro</button>
                </div>

                <ul class="med-list">
                    ${meds.length > 0 ? meds.map(m => `
                        <li class="med-item">
                            <div class="med-info">
                                <h4>${m.name}</h4>
                                <p>${m.dose}</p>
                            </div>
                            <button class="status-badge" style="background: rgba(239, 68, 68, 0.1); color: var(--error); border: none; cursor: pointer;" onclick="window.removeMed(${m.id})">Eliminar</button>
                        </li>
                    `).join('') : '<p>No hay registros.</p>'}
                </ul>
            </div>
        `;

        document.getElementById('add-med-btn').onclick = () => {
            const form = document.getElementById('med-form-container');
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        };

        document.getElementById('save-med-btn').onclick = () => {
            const name = document.getElementById('new-med-name').value;
            const dose = document.getElementById('new-med-dose').value;
            if (name && dose) {
                saveMedication({ name, dose });
                loadSection('medications');
            }
        };
    }

    function renderReminders() {
        contentArea.innerHTML = `
            <div class="widget-card animate-in text-center">
                <h3 class="widget-title">Alertas para ${selectedPatientQSL}</h3>
                <p style="color:var(--text-muted)">Solo los pacientes reciben alertas sonoras en tiempo real.</p>
                <div style="margin-top: 20px; padding: 40px; text-align: center; border: 2px dashed var(--card-border); border-radius: 20px;">
                    ${userRole === 'paciente' ? '<button class="btn-primary">Activar Alarma de Prueba</button>' : '<p>Vista de monitoreo para el médico</p>'}
                </div>
            </div>
        `;
    }

    function renderSettings() {
        contentArea.innerHTML = `
            <div class="widget-card animate-in">
                <h3 class="widget-title">Configuración (${userRole})</h3>
                <div class="input-group" style="margin-bottom: 20px;">
                    <label>Tu Identificación</label>
                    <input type="text" value="${qslCode}" disabled style="opacity: 0.7">
                </div>
                <button class="btn-primary" onclick="localStorage.clear(); window.location.href='index.html';" style="background: var(--error)">
                    Cerrar Todo y Borrar Caché
                </button>
            </div>
        `;
    }

    window.removeMed = (id) => {
        const meds = getMedications().filter(m => m.id !== id);
        localStorage.setItem(getStorageKey('meds'), JSON.stringify(meds));
        loadSection('medications');
    };

    function getSectionTitle(name) {
        const titles = {
            'overview': 'Resumen',
            'medications': 'Medicación',
            'reminders': 'Alertas',
            'settings': 'Opciones'
        };
        return titles[name] || 'H-Control';
    }

    function updateDate() {
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        dateDisplay.textContent = new Date().toLocaleDateString('es-ES', options);
    }
});
