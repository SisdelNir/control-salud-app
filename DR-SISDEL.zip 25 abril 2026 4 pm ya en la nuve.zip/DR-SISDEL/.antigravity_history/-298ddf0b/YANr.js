document.addEventListener('DOMContentLoaded', () => {
    // 1. Estado y Sesión
    const qslCode = localStorage.getItem('user_qsl_code');
    const userRole = localStorage.getItem('user_role');
    const userRealName = localStorage.getItem('user_real_name');

    if (!qslCode || !userRole) {
        window.location.href = 'index.html';
        return;
    }

    // Referencias UI
    const qslDisplay = document.getElementById('display-qsl');
    const logoutBtn = document.getElementById('logout-btn');
    const contentArea = document.getElementById('content-area');
    const sectionTitle = document.getElementById('section-title');
    const navItems = document.querySelectorAll('.nav-links li[data-section]');
    const dateDisplay = document.getElementById('current-date');

    let selectedPatientQSL = userRole === 'paciente' ? qslCode : null;

    // Inicialización
    updateUserDisplay();
    updateDate();
    loadSection('overview');

    function updateUserDisplay() {
        const name = localStorage.getItem('user_real_name') || qslCode;
        qslDisplay.textContent = userRole === 'medico' ? `Dr. ${name}` : `Paciente: ${name}`;
    }

    // Navegación
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            loadSection(section);
        });
    });

    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('user_qsl_code');
        localStorage.removeItem('user_role');
        window.location.href = 'index.html';
    });

    // 2. Gestión de Datos Médico
    function getPatientData(qsl) {
        const data = localStorage.getItem(`patient_data_${qsl}`);
        return data ? JSON.parse(data) : { illness: '', meds: [] };
    }

    function savePatientData(qsl, data) {
        localStorage.setItem(`patient_data_${qsl}`, JSON.stringify(data));
        // Registrar QSL en la lista global de pacientes del médico si no existe
        let list = JSON.parse(localStorage.getItem('doctor_patients_list') || '[]');
        if (!list.includes(qsl)) {
            list.push(qsl);
            localStorage.setItem('doctor_patients_list', JSON.stringify(list));
        }
    }

    // 3. Motor de Secciones
    function loadSection(sectionName) {
        sectionTitle.textContent = getSectionTitle(sectionName);
        contentArea.innerHTML = `<div class="loading-state"><div class="spinner"></div></div>`;
        setTimeout(() => renderSection(sectionName), 300);
    }

    function renderSection(name) {
        if (userRole === 'medico' && !selectedPatientQSL && name !== 'settings') {
            renderDoctorHome();
            return;
        }

        const data = getPatientData(selectedPatientQSL);

        switch (name) {
            case 'overview': renderOverview(data); break;
            case 'medications': renderMedicationModule(data); break;
            case 'reminders': renderReminders(data); break;
            case 'settings': renderSettings(); break;
        }
    }

    // --- VISTAS DEL MÉDICO ---

    function renderDoctorHome() {
        const patients = JSON.parse(localStorage.getItem('doctor_patients_list') || '[]');

        contentArea.innerHTML = `
            <div class="widget-card animate-in" style="max-width: 600px; margin: 0 auto;">
                <h3 class="widget-title">Panel Médico: Mis Pacientes</h3>
                <div class="input-group" style="margin-bottom: 20px; display: flex; gap: 10px;">
                    <input type="text" id="new-patient-qsl" placeholder="Nuevo Código QSL..." style="text-transform: uppercase;">
                    <button id="btn-add-patient" class="btn-primary" style="margin:0; padding: 10px 20px;">Registrar</button>
                </div>

                <div class="patient-list">
                    ${patients.length > 0 ? patients.map(qsl => {
            const name = localStorage.getItem(`patient_name_${qsl}`) || 'Paciente Nuevo';
            return `
                            <div class="med-item" style="cursor: pointer;" onclick="window.selectPatient('${qsl}')">
                                <div class="med-info">
                                    <h4>${name}</h4>
                                    <p>QSL: ${qsl}</p>
                                </div>
                                <span class="status-badge" style="background: var(--accent); color: white;">Abrir Expediente</span>
                            </div>
                        `;
        }).join('') : '<p style="text-align:center; color: var(--text-muted);">No hay pacientes registrados.</p>'}
                </div>
            </div>
        `;

        document.getElementById('btn-add-patient').onclick = () => {
            const qsl = document.getElementById('new-patient-qsl').value.trim().toUpperCase();
            if (qsl.length >= 3) {
                selectedPatientQSL = qsl;
                loadSection('overview');
            } else { alert('Ingrese un código QSL válido.'); }
        };
    }

    window.selectPatient = (qsl) => {
        selectedPatientQSL = qsl;
        loadSection('overview');
    };

    function renderOverview(data) {
        const patientName = localStorage.getItem(`patient_name_${selectedPatientQSL}`) || 'Paciente';
        contentArea.innerHTML = `
            <div class="dashboard-grid">
                <div class="widget-card animate-in">
                    <h3 class="widget-title">Expediente Clínico</h3>
                    <div style="margin: 15px 0;">
                        <p style="font-size: 14px; color: var(--accent)">${patientName} (${selectedPatientQSL})</p>
                    </div>
                    
                    <div class="input-group">
                        <label>Enfermedad o Condición a Tratar</label>
                        <input type="text" id="patient-illness" value="${data.illness || ''}" placeholder="Ej: Hipertensión Arterial">
                        <button class="btn-primary" style="margin-top: 10px; font-size: 12px;" onclick="window.savePatientIllness()">GUARDAR DIAGNÓSTICO</button>
                    </div>

                    <h4 style="margin-top: 25px; margin-bottom: 15px; font-size: 13px; text-transform: uppercase;">Medicación Vigente</h4>
                    <div class="med-list">
                        ${data.meds.length > 0 ? data.meds.map(m => `
                            <div class="med-item">
                                <div class="med-info">
                                    <h4>${m.name}</h4>
                                    <p>${m.dose} - Cada ${m.frequency}h</p>
                                </div>
                                <span class="status-badge">Activo</span>
                            </div>
                        `).join('') : '<p style="color: var(--text-muted)">Sin medicamentos asignados.</p>'}
                    </div>
                </div>

                <div class="widget-card animate-in" style="animation-delay: 0.1s">
                    <h3 class="widget-title">Control de Conexión</h3>
                    <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 20px;">
                        Active este código para que el paciente reciba las alertas en su dispositivo móvil.
                    </p>
                    <div style="text-align: center; padding: 20px; background: rgba(0,0,0,0.2); border-radius: 15px;">
                        <h2 style="color: var(--accent); margin-bottom: 10px;">${selectedPatientQSL}</h2>
                        <button class="btn-primary" onclick="window.activateCode('${selectedPatientQSL}')" style="width: 100%; background: #10b981;">
                            ACTIVAR CÓDIGO CELULAR
                        </button>
                    </div>
                    ${userRole === 'medico' ? `
                        <button class="btn-primary" style="width: 100%; margin-top: 20px; background: rgba(255,255,255,0.05);" onclick="selectedPatientQSL=null; loadSection('overview')">Volver a Lista de Pacientes</button>
                    ` : ''}
                </div>
            </div>
        `;
    }

    window.savePatientIllness = () => {
        const val = document.getElementById('patient-illness').value.trim();
        const data = getPatientData(selectedPatientQSL);
        data.illness = val;
        savePatientData(selectedPatientQSL, data);
        alert('Diagnóstico guardado con éxito.');
    };

    window.activateCode = (qsl) => {
        // En un sistema real, esto activaría un socket o notificación push.
        // Aquí simulamos que el QSL ahora es "rastreable".
        localStorage.setItem(`active_qsl_${qsl}`, 'true');
        alert(`¡Código ${qsl} activado! El paciente ahora recibirá sus recordatorios.`);
    };

    function renderMedicationModule(data) {
        contentArea.innerHTML = `
            <div class="widget-card animate-in">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                    <h3 class="widget-title">Asignación de Medicamentos</h3>
                    ${userRole === 'medico' ? `<button id="add-btn" class="btn-primary" style="margin:0; padding: 8px 15px;">+ Nueva Receta</button>` : ''}
                </div>

                <div id="med-form" style="display: none; background: rgba(0,0,0,0.2); padding: 20px; border-radius: 20px; margin-bottom: 20px;">
                    <div class="dashboard-grid">
                        <div class="input-group">
                            <label>Nombre Medicamento</label>
                            <input type="text" id="m-name">
                        </div>
                        <div class="input-group">
                            <label>Dosis / Cantidad</label>
                            <input type="text" id="m-dose">
                        </div>
                        <div class="input-group">
                            <label>Frecuencia (Horas)</label>
                            <input type="number" id="m-freq" placeholder="Ej: 8">
                        </div>
                        <div class="input-group">
                            <label>Comenzar a las:</label>
                            <input type="time" id="m-start" value="08:00">
                        </div>
                        <div class="input-group">
                            <label>Periodo de Tratamiento (Días)</label>
                            <input type="number" id="m-days" placeholder="Ej: 7">
                        </div>
                    </div>
                    <div class="input-group" style="margin-top: 15px;">
                        <label>Indicaciones Extra</label>
                        <input type="text" id="m-notes">
                    </div>
                    <div style="display: flex; gap: 10px; margin-top: 20px;">
                        <button id="btn-med-save" class="btn-primary" style="flex: 2;">GUARDAR EN EXPEDIENTE</button>
                        <button id="btn-med-cancel" class="btn-primary" style="flex: 1; background: transparent; border: 1px solid var(--card-border);">Cancelar</button>
                    </div>
                </div>

                <div class="med-list">
                    ${data.meds.length > 0 ? data.meds.map(m => `
                        <div class="widget-card" style="margin-bottom: 10px; background: rgba(255,255,255,0.02);">
                            <div style="display: flex; justify-content: space-between;">
                                <div class="med-info">
                                    <h4 style="color: var(--accent)">${m.name}</h4>
                                    <p>Dosis: ${m.dose} | Cada ${m.frequency}h durante ${m.days} días</p>
                                    <p style="font-size: 11px; opacity: 0.6; font-style: italic;">"${m.notes || 'Sin notas'}"</p>
                                </div>
                                ${userRole === 'medico' ? `<button class="status-badge" style="background: rgba(239, 68, 68, 0.1); color: var(--error); border:none; cursor:pointer;" onclick="window.deleteMed(${m.id})">QUITAR</button>` : ''}
                            </div>
                        </div>
                    `).join('') : '<p style="text-align: center; color: var(--text-muted);">No hay medicamentos asignados aún.</p>'}
                </div>
            </div>
        `;

        if (userRole === 'medico') {
            document.getElementById('add-btn').onclick = () => {
                document.getElementById('med-form').style.display = 'block';
                document.getElementById('add-btn').style.display = 'none';
            };
            document.getElementById('btn-med-cancel').onclick = () => {
                document.getElementById('med-form').style.display = 'none';
                document.getElementById('add-btn').style.display = 'block';
            };
            document.getElementById('btn-med-save').onclick = () => {
                const med = {
                    id: Date.now(),
                    name: document.getElementById('m-name').value,
                    dose: document.getElementById('m-dose').value,
                    frequency: document.getElementById('m-freq').value,
                    startTime: document.getElementById('m-start').value,
                    days: document.getElementById('m-days').value,
                    notes: document.getElementById('m-notes').value
                };
                if (med.name && med.dose && med.frequency) {
                    const patientData = getPatientData(selectedPatientQSL);
                    patientData.meds.push(med);
                    savePatientData(selectedPatientQSL, patientData);
                    loadSection('medications');
                } else { alert('Complete los campos obligatorios'); }
            };
        }
    }

    window.deleteMed = (id) => {
        if (confirm('¿Eliminar medicamento del expediente?')) {
            const data = getPatientData(selectedPatientQSL);
            data.meds = data.meds.filter(m => m.id !== id);
            savePatientData(selectedPatientQSL, data);
            loadSection('medications');
        }
    };

    function renderReminders(data) {
        contentArea.innerHTML = `
            <div class="widget-card animate-in text-center">
                <h3 class="widget-title">Alertas Activas</h3>
                <p style="color: var(--text-muted); margin-bottom: 20px;">Monitoreo de notificaciones para el paciente actual.</p>
                <div class="dashboard-grid">
                    ${data.meds.map(m => `
                        <div class="widget-card" style="background: rgba(0,0,0,0.2); text-align: left;">
                            <h4 style="color: var(--accent)">${m.name}</h4>
                            <p style="font-size: 13px;">Próximo en: ${calculateNextDose(m.startTime, m.frequency)}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    function renderSettings() {
        const isDoc = userRole === 'medico';
        contentArea.innerHTML = `
            <div class="widget-card animate-in" style="max-width: 500px; margin: 0 auto;">
                <h3 class="widget-title">Configuración de Perfil</h3>
                <div class="input-group" style="margin-bottom: 20px;">
                    <label>Nombre Maestro (Médico)</label>
                    <input type="text" id="new-doc-name" value="${isDoc ? localStorage.getItem('doctor_master_name') : ''}" ${!isDoc ? 'disabled' : ''}>
                </div>
                <div class="input-group" style="margin-bottom: 20px;">
                    <label>Nueva Clave de Acceso</label>
                    <input type="password" id="new-doc-pass" placeholder="Ingresar nueva clave..." ${!isDoc ? 'disabled' : ''}>
                </div>
                ${isDoc ? `
                    <button class="btn-primary" style="width: 100%; margin-bottom: 20px;" onclick="window.updateDocProfile()">GUARDAR CAMBIOS DE ACCESO</button>
                ` : '<p style="font-size: 11px; color: var(--text-muted);">Los pacientes gestionan su perfil mediante su código QSL único.</p>'}
                <hr style="border:0; border-top: 1px solid var(--card-border); margin: 20px 0;">
                <button class="btn-primary" style="width: 100%; background: var(--error);" onclick="localStorage.removeItem('user_qsl_code'); window.location.href='index.html';">CERRAR SESIÓN</button>
            </div>
        `;
    }

    window.updateDocProfile = () => {
        const name = document.getElementById('new-doc-name').value.trim();
        const pass = document.getElementById('new-doc-pass').value.trim();
        if (name) {
            localStorage.setItem('doctor_master_name', name);
            localStorage.setItem('user_real_name', name);
            if (pass) {
                localStorage.setItem('doctor_master_pass', btoa(pass));
                alert('Nombre y Clave actualizados. Se aplicarán la próxima vez que ingrese.');
            } else {
                alert('Nombre actualizado.');
            }
            updateUserDisplay();
        }
    };

    // --- UTILIDADES ---
    function calculateNextDose(startTime, freq) {
        if (!startTime || !freq) return '--:--';
        try {
            const now = new Date();
            const [h, m] = startTime.split(':');
            let next = new Date(now.getFullYear(), now.getMonth(), now.getDate(), parseInt(h), parseInt(m));
            const freqMs = parseInt(freq) * 3600000;
            while (next <= now) { next = new Date(next.getTime() + freqMs); }
            return next.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } catch (e) { return '--:--'; }
    }

    function getSectionTitle(name) {
        const titles = { overview: 'Expediente', medications: 'Tratamiento', reminders: 'Seguimiento', settings: 'Perfil' };
        return titles[name] || 'H-Control';
    }

    function updateDate() {
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        dateDisplay.textContent = new Date().toLocaleDateString('es-ES', options);
    }
});
