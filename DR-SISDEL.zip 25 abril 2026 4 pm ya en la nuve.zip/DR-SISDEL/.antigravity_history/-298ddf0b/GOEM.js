document.addEventListener('DOMContentLoaded', () => {
    // 1. Verificar Acceso
    const qslCode = localStorage.getItem('user_qsl_code');
    if (!qslCode) {
        window.location.href = 'index.html';
        return;
    }

    // 2. Referencias UI
    const qslDisplay = document.getElementById('display-qsl');
    const logoutBtn = document.getElementById('logout-btn');
    const contentArea = document.getElementById('content-area');
    const sectionTitle = document.getElementById('section-title');
    const navItems = document.querySelectorAll('.nav-links li[data-section]');
    const dateDisplay = document.getElementById('current-date');

    // 3. Inicialización
    qslDisplay.textContent = `QSL: ${qslCode}`;
    updateDate();
    loadSection('overview');

    // 4. Manejo de Navegación
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');

            // Actualizar UI de navegación
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            loadSection(section);
        });
    });

    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('user_qsl_code');
        window.location.href = 'index.html';
    });

    // 5. Motor de Datos (Vinculado al QSL)
    function getStorageKey(suffix) {
        return `health_${qslCode}_${suffix}`;
    }

    function getMedications() {
        const meds = localStorage.getItem(getStorageKey('meds'));
        return meds ? JSON.parse(meds) : [];
    }

    function saveMedication(med) {
        const meds = getMedications();
        meds.push({ ...med, id: Date.now() });
        localStorage.setItem(getStorageKey('meds'), JSON.stringify(meds));
    }

    // 6. Motor de Secciones
    function loadSection(sectionName) {
        sectionTitle.textContent = getSectionTitle(sectionName);

        contentArea.innerHTML = `
            <div class="loading-state">
                <div class="spinner"></div>
            </div>
        `;

        setTimeout(() => {
            renderSection(sectionName);
        }, 300);
    }

    function renderSection(name) {
        const medications = getMedications();

        switch (name) {
            case 'overview':
                const pendingMeds = medications.slice(0, 3);
                contentArea.innerHTML = `
                    <div class="dashboard-grid">
                        <div class="widget-card animate-in">
                            <h3 class="widget-title">Resumen para QSL: ${qslCode}</h3>
                            <p style="margin-bottom: 15px; font-size: 14px; color: var(--text-muted)">
                                Datos exclusivos para este perfil.
                            </p>
                            <h4 style="margin-bottom: 10px; font-size: 14px;">Próximas Tomas</h4>
                            <ul class="med-list">
                                ${pendingMeds.length > 0 ? pendingMeds.map(m => `
                                    <li class="med-item">
                                        <div class="med-info">
                                            <h4>${m.name}</h4>
                                            <p>${m.dose} - ${m.time || 'Pendiente'}</p>
                                        </div>
                                        <span class="status-badge">Activo</span>
                                    </li>
                                `).join('') : '<p style="color: var(--text-muted); font-size: 13px;">No hay medicamentos registrados todavía.</p>'}
                            </ul>
                        </div>
                        <div class="widget-card animate-in" style="animation-delay: 0.1s">
                            <h3 class="widget-title">Estadísticas Rápidas</h3>
                            <div class="health-stats">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                                    <span>Medicamentos:</span>
                                    <span style="color: var(--accent)">${medications.length}</span>
                                </div>
                                <div style="display: flex; justify-content: space-between;">
                                    <span>Último Acceso:</span>
                                    <span style="color: var(--accent)">Hoy</span>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                break;

            case 'medications':
                contentArea.innerHTML = `
                    <div class="widget-card animate-in">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                            <h3 class="widget-title">Gestión de Medicamentos</h3>
                            <button id="add-med-btn" class="btn-primary" style="padding: 8px 16px; font-size: 13px; margin: 0;">
                                + Agregar
                            </button>
                        </div>
                        
                        <div id="med-form-container" style="display: none; margin-bottom: 30px; padding: 20px; background: rgba(0,0,0,0.2); border-radius: 15px;">
                            <div class="input-group" style="margin-bottom: 15px;">
                                <label>Nombre del Medicamento</label>
                                <input type="text" id="new-med-name" placeholder="Ej: Paracetamol">
                            </div>
                            <div class="input-group" style="margin-bottom: 15px;">
                                <label>Dosis / Frecuencia</label>
                                <input type="text" id="new-med-dose" placeholder="Ej: 500mg cada 8h">
                            </div>
                            <button id="save-med-btn" class="btn-primary" style="width: 100%;">Guardar Medicamento</button>
                        </div>

                        <ul class="med-list">
                            ${medications.length > 0 ? medications.map(m => `
                                <li class="med-item">
                                    <div class="med-info">
                                        <h4>${m.name}</h4>
                                        <p>${m.dose}</p>
                                    </div>
                                    <button class="status-badge" style="background: rgba(239, 68, 68, 0.1); color: var(--error); border: none; cursor: pointer;" onclick="window.removeMed(${m.id})">Eliminar</button>
                                </li>
                            `).join('') : '<p>No hay medicamentos registrados.</p>'}
                        </ul>
                    </div>
                `;

                // Eventos de la sección medicamentos
                document.getElementById('add-med-btn').onclick = () => {
                    const form = document.getElementById('med-form-container');
                    form.style.display = form.style.display === 'none' ? 'block' : 'none';
                };

                document.getElementById('save-med-btn').onclick = () => {
                    const name = document.getElementById('new-med-name').value;
                    const dose = document.getElementById('new-med-dose').value;
                    if (name && dose) {
                        saveMedication({ name, dose });
                        loadSection('medications');
                    }
                };
                break;

            case 'reminders':
                contentArea.innerHTML = `
                    <div class="widget-card animate-in">
                        <h3 class="widget-title">Alarmas para QSL: ${qslCode}</h3>
                        <p style="color: var(--text-muted)">Configure alertas sonoras para sus medicamentos.</p>
                        <div style="margin-top: 20px; padding: 40px; text-align: center; border: 2px dashed var(--card-border); border-radius: 20px;">
                            <p>Módulo de Notificaciones en Desarrollo</p>
                        </div>
                    </div>
                `;
                break;

            case 'settings':
                contentArea.innerHTML = `
                    <div class="widget-card animate-in">
                        <h3 class="widget-title">Configuración del Perfil</h3>
                        <div class="input-group" style="margin-bottom: 20px;">
                            <label>Código QSL Actual</label>
                            <input type="text" value="${qslCode}" disabled style="opacity: 0.7">
                        </div>
                        <button class="btn-primary" onclick="localStorage.clear(); window.location.reload();" style="background: var(--error)">
                            Borrar Todos los Datos Locales
                        </button>
                    </div>
                `;
                break;
        }
    }

    // Función global para eliminar (usada en el HTML generado)
    window.removeMed = (id) => {
        const meds = getMedications().filter(m => m.id !== id);
        localStorage.setItem(getStorageKey('meds'), JSON.stringify(meds));
        loadSection('medications');
    };

    function getSectionTitle(name) {
        const titles = {
            'overview': 'Resumen de Salud',
            'medications': 'Mis Medicamentos',
            'reminders': 'Alarmas y Recordatorios',
            'settings': 'Configuración'
        };
        return titles[name] || 'Control de Salud';
    }

    function updateDate() {
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        dateDisplay.textContent = new Date().toLocaleDateString('es-ES', options);
    }
});
