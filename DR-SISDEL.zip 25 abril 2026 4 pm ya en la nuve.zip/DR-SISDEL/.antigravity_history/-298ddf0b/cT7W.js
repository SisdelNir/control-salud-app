document.addEventListener('DOMContentLoaded', () => {
    // 1. Estado y Sesión
    const qslCode = localStorage.getItem('user_qsl_code');
    const userRole = localStorage.getItem('user_role');
    const userRealName = localStorage.getItem('user_real_name');

    if (!qslCode || !userRole) {
        window.location.href = 'index.html';
        return;
    }

    // Referencias UI
    const qslDisplay = document.getElementById('display-qsl');
    const logoutBtn = document.getElementById('logout-btn');
    const contentArea = document.getElementById('content-area');
    const sectionTitle = document.getElementById('section-title');
    const navItems = document.querySelectorAll('.nav-links li[data-section]');
    const dateDisplay = document.getElementById('current-date');

    let selectedPatientQSL = userRole === 'paciente' ? qslCode : null;

    // Inicialización
    updateUserDisplay();
    updateDate();
    if (userRole === 'paciente') {
        navItems.forEach(n => n.classList.remove('active'));
        const targetNav = Array.from(navItems).find(n => n.getAttribute('data-section') === 'reminders');
        if (targetNav) targetNav.classList.add('active');
        loadSection('reminders');
    } else {
        loadSection('overview');
    }

    function updateUserDisplay() {
        const name = localStorage.getItem('user_real_name') || qslCode;
        qslDisplay.textContent = userRole === 'medico' ? `Dr. ${name}` : `Paciente: ${name}`;
    }

    // Navegación
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            loadSection(section);
        });
    });

    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('user_qsl_code');
        localStorage.removeItem('user_role');
        window.location.href = 'index.html';
    });

    // 2. Gestión de Datos Médico
    function getPatientData(qsl) {
        const data = localStorage.getItem(`patient_data_${qsl}`);
        return data ? JSON.parse(data) : { illness: '', meds: [] };
    }

    function savePatientData(qsl, data) {
        localStorage.setItem(`patient_data_${qsl}`, JSON.stringify(data));
        // Registrar QSL en la lista global de pacientes del médico si no existe
        let list = JSON.parse(localStorage.getItem('doctor_patients_list') || '[]');
        if (!list.includes(qsl)) {
            list.push(qsl);
            localStorage.setItem('doctor_patients_list', JSON.stringify(list));
        }
    }

    // 3. Motor de Secciones
    function loadSection(sectionName) {
        sectionTitle.textContent = getSectionTitle(sectionName);
        contentArea.innerHTML = `<div class="loading-state"><div class="spinner"></div></div>`;
        setTimeout(() => renderSection(sectionName), 300);
    }

    function renderSection(name) {
        if (userRole === 'medico' && !selectedPatientQSL && name !== 'settings') {
            renderDoctorHome();
            return;
        }

        const data = getPatientData(selectedPatientQSL);

        switch (name) {
            case 'overview': renderOverview(data); break;
            case 'reminders': renderReminders(data); break;
            case 'settings': renderSettings(); break;
        }
    }

    // --- VISTAS DEL MÉDICO ---

    function renderDoctorHome() {
        const patients = JSON.parse(localStorage.getItem('doctor_patients_list') || '[]');

        contentArea.innerHTML = `
            <div class="widget-card animate-in" style="max-width: 650px; margin: 0 auto;">
                <h3 class="widget-title" style="color: var(--accent); border-bottom: 1px solid var(--card-border); padding-bottom: 15px;">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/>
                    </svg>
                    Nuevo Expediente Clínico
                </h3>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; padding: 20px; background: rgba(0,0,0,0.2); border-radius: 20px;">
                    <div class="input-group">
                        <label>Nombre del Paciente</label>
                        <input type="text" id="new-patient-name" placeholder="Nombre completo...">
                    </div>
                    <div class="input-group">
                        <label>Código de Acceso</label>
                        <input type="text" id="new-patient-qsl" placeholder="Se asignará automáticamente" disabled style="opacity: 0.6;">
                    </div>
                    <div class="input-group" style="grid-column: span 2;">
                        <label>Diagnóstico / Enfermedad</label>
                        <input type="text" id="new-patient-illness" placeholder="Ej: Diabetes Tipo 2, Hipertensión...">
                    </div>
                    <button id="btn-add-patient" class="btn-primary" style="grid-column: span 2; margin-top: 10px;">
                        <span>GUARDAR Y ABRIR EXPEDIENTE</span>
                    </button>
                </div>

                <h3 class="widget-title" style="font-size: 15px; opacity: 0.8;">Expedientes Activos (${patients.length})</h3>
                <div class="patient-list">
                    ${patients.length > 0 ? patients.map(qsl => {
            const name = localStorage.getItem(`patient_name_${qsl}`) || 'Paciente sin nombre';
            const data = getPatientData(qsl);
            return `
                            <div class="med-item" style="cursor: pointer; transition: 0.3s;" onclick="window.selectPatient('${qsl}')">
                                <div class="med-info">
                                    <h4 style="color: white; font-size: 17px;">${name}</h4>
                                    <p style="color: var(--text-muted); font-size: 12px;">QSL: <b style="color:var(--accent)">${qsl}</b> | ${data.illness || 'Sin diagnóstico'}</p>
                                </div>
                                <div style="text-align: right;">
                                    <span class="status-badge" style="background: rgba(34, 211, 238, 0.1);">Ver Detalle</span>
                                </div>
                            </div>
                        `;
        }).join('') : '<div style="text-align:center; padding: 30px; opacity: 0.5;">No hay expedientes registrados todavía.</div>'}
                </div>
            </div>
        `;

        document.getElementById('btn-add-patient').onclick = () => {
            const name = document.getElementById('new-patient-name').value.trim();
            const illness = document.getElementById('new-patient-illness').value.trim();

            if (name) {
                // Generar QSL Automático (Primera letra + número incremental)
                const firstLetter = name.charAt(0).toUpperCase() || 'A';
                let counter = 1;
                let qsl = `${firstLetter}${counter}`;

                const existingPatients = JSON.parse(localStorage.getItem('doctor_patients_list') || '[]');
                while (existingPatients.includes(qsl)) {
                    counter++;
                    qsl = `${firstLetter}${counter}`;
                }

                // Guardar Nombre y Diagnóstico inicial
                localStorage.setItem(`patient_name_${qsl}`, name);
                const data = getPatientData(qsl);
                data.illness = illness;
                savePatientData(qsl, data);

                selectedPatientQSL = qsl;
                loadSection('overview');
            } else {
                alert('Por favor, ingrese al menos el nombre del paciente.');
            }
        };
    }

    window.selectPatient = (qsl) => {
        selectedPatientQSL = qsl;
        loadSection('overview');
    };

    function renderOverview(data) {
        const patientName = localStorage.getItem(`patient_name_${selectedPatientQSL}`) || 'Paciente';
        contentArea.innerHTML = `
            <div class="dashboard-grid">
                <div class="widget-card animate-in">
                    <h3 class="widget-title">Expediente Clínico</h3>
                    <div style="margin: 15px 0;">
                        <p style="font-size: 14px; color: var(--accent)">${patientName} (${selectedPatientQSL})</p>
                    </div>
                    
                    <div class="input-group">
                        <label>Enfermedad o Condición a Tratar</label>
                        <input type="text" id="patient-illness" value="${data.illness || ''}" placeholder="Ej: Hipertensión Arterial">
                        <button class="btn-primary" style="margin-top: 10px; font-size: 12px;" onclick="window.savePatientIllness()">GUARDAR DIAGNÓSTICO</button>
                    </div>

                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 30px; margin-bottom: 15px;">
                        <h4 style="font-size: 13px; text-transform: uppercase; margin: 0;">Medicación Vigente / Recetas</h4>
                        ${userRole === 'medico' ? `<button id="add-btn" class="btn-primary" style="margin:0; padding: 5px 15px; font-size: 11px;">+ Nueva Receta</button>` : ''}
                    </div>

                    <div id="med-form" style="display: none; background: rgba(0,0,0,0.2); padding: 20px; border-radius: 20px; margin-bottom: 20px;">
                        <div class="dashboard-grid">
                            <div class="input-group">
                                <label>Nombre Medicamento</label>
                                <input type="text" id="m-name">
                            </div>
                            <div class="input-group">
                                <label>Dosis / Cantidad</label>
                                <input type="text" id="m-dose">
                            </div>
                            <div class="input-group">
                                <label>Frecuencia (Horas)</label>
                                <input type="number" id="m-freq" placeholder="Ej: 8">
                            </div>
                            <div class="input-group">
                                <label>Comenzar a las:</label>
                                <input type="time" id="m-start" value="08:00">
                            </div>
                            <div class="input-group">
                                <label>Periodo de Tratamiento (Días)</label>
                                <input type="number" id="m-days" placeholder="Ej: 7">
                            </div>
                        </div>
                        <div class="input-group" style="margin-top: 15px;">
                            <label>Indicaciones Extra</label>
                            <input type="text" id="m-notes">
                        </div>
                        <div style="display: flex; gap: 10px; margin-top: 20px;">
                            <button id="btn-med-save" class="btn-primary" style="flex: 2;">GUARDAR RECETA AL EXPEDIENTE</button>
                            <button id="btn-med-cancel" class="btn-primary" style="flex: 1; background: transparent; border: 1px solid var(--card-border);">Cancelar</button>
                        </div>
                    </div>

                    <div class="med-list">
                        ${data.meds.length > 0 ? data.meds.map(m => `
                            <div class="widget-card" style="margin-bottom: 10px; background: rgba(255,255,255,0.02); padding: 15px;">
                                <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                                    <div class="med-info">
                                        <h4 style="color: var(--accent); margin-bottom: 5px;">${m.name}</h4>
                                        <p style="font-size: 13px;">Dosis: ${m.dose} | Cada ${m.frequency}h durante ${m.days} días</p>
                                        <p style="font-size: 12px; color: var(--text-muted); font-style: italic; margin-top: 5px;">"${m.notes || 'Sin notas'}"</p>
                                    </div>
                                    ${userRole === 'medico' ? `<button class="status-badge" style="background: rgba(239, 68, 68, 0.1); color: var(--error); border:none; cursor:pointer;" onclick="window.deleteMed(${m.id})">QUITAR</button>` : '<span class="status-badge">Activo</span>'}
                                </div>
                            </div>
                        `).join('') : '<p style="text-align: center; color: var(--text-muted);">Sin medicamentos/recetas asignados todavía.</p>'}
                    </div>
                </div>

                <div class="widget-card animate-in" style="animation-delay: 0.1s">
                    <h3 class="widget-title">Control de Conexión</h3>
                    <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 20px;">
                        Active este código para que el paciente reciba las alertas en su dispositivo móvil.
                    </p>
                    <div style="text-align: center; padding: 20px; background: rgba(0,0,0,0.2); border-radius: 15px;">
                        <h2 style="color: var(--accent); margin-bottom: 10px;">${selectedPatientQSL}</h2>
                        <button class="btn-primary" onclick="window.activateCode('${selectedPatientQSL}')" style="width: 100%; background: #10b981;">
                            ACTIVAR CÓDIGO CELULAR
                        </button>
                    </div>
                    ${userRole === 'medico' ? `
                        <button class="btn-primary" style="width: 100%; margin-top: 20px; background: rgba(255,255,255,0.05);" onclick="selectedPatientQSL=null; loadSection('overview')">Volver a Lista de Pacientes</button>
                    ` : ''}
                </div>
            </div>
        `;

        if (userRole === 'medico') {
            const addBtn = document.getElementById('add-btn');
            if (addBtn) {
                addBtn.onclick = () => {
                    document.getElementById('med-form').style.display = 'block';
                    addBtn.style.display = 'none';
                };
            }

            const btnCancel = document.getElementById('btn-med-cancel');
            if (btnCancel) {
                btnCancel.onclick = () => {
                    document.getElementById('med-form').style.display = 'none';
                    if (addBtn) addBtn.style.display = 'block';
                };
            }

            const btnSave = document.getElementById('btn-med-save');
            if (btnSave) {
                btnSave.onclick = () => {
                    const med = {
                        id: Date.now(),
                        name: document.getElementById('m-name').value,
                        dose: document.getElementById('m-dose').value,
                        frequency: document.getElementById('m-freq').value,
                        startTime: document.getElementById('m-start').value,
                        days: document.getElementById('m-days').value,
                        notes: document.getElementById('m-notes').value
                    };
                    if (med.name && med.dose && med.frequency) {
                        const patientData = getPatientData(selectedPatientQSL);
                        patientData.meds.push(med);
                        savePatientData(selectedPatientQSL, patientData);
                        loadSection('overview');
                    } else { alert('Complete los campos obligatorios'); }
                };
            }
        }

    }

    window.savePatientIllness = () => {
        const val = document.getElementById('patient-illness').value.trim();
        const data = getPatientData(selectedPatientQSL);
        data.illness = val;
        savePatientData(selectedPatientQSL, data);
        alert('Diagnóstico guardado con éxito.');
    };

    window.activateCode = (qsl) => {
        // En un sistema real, esto activaría un socket o notificación push.
        // Aquí simulamos que el QSL ahora es "rastreable".
        localStorage.setItem(`active_qsl_${qsl}`, 'true');
        alert(`¡Código ${qsl} activado! El paciente ahora recibirá sus recordatorios.`);
    };



    window.deleteMed = (id) => {
        if (confirm('¿Eliminar medicamento del expediente?')) {
            const data = getPatientData(selectedPatientQSL);
            data.meds = data.meds.filter(m => m.id !== id);
            savePatientData(selectedPatientQSL, data);
            loadSection('overview');
        }
    };

    function renderReminders(data) {
        contentArea.innerHTML = `
            <div class="widget-card animate-in text-center">
                <h3 class="widget-title">Alertas Activas</h3>
                <p style="color: var(--text-muted); margin-bottom: 20px;">Monitoreo de notificaciones para el paciente actual.</p>
                <div class="dashboard-grid">
                    ${data.meds.map(m => {
            const nextDose = calculateNextDose(m.startTime, m.frequency);
            const isDue = isDoseDue(m.startTime, m.frequency);
            return `
                        <div class="widget-card" style="background: rgba(0,0,0,0.2); text-align: left; ${isDue ? 'border: 2px solid var(--accent); box-shadow: 0 0 15px rgba(34, 211, 238, 0.5); animation: pulse 2s infinite;' : ''}" id="med-card-${m.id}">
                            <h4 style="color: var(--accent); font-size: 18px; margin-bottom: 10px;">${m.name}</h4>
                            <p style="font-size: 14px; margin-bottom: 5px;"><strong>Dosis:</strong> ${m.dose}</p>
                            <p style="font-size: 14px; margin-bottom: 15px;"><strong>Próximo en:</strong> ${nextDose}</p>
                            ${isDue ? `
                                <div style="background: rgba(34, 211, 238, 0.1); padding: 15px; border-radius: 12px; margin-bottom: 15px;">
                                    <p style="color: var(--accent); font-weight: bold; font-size: 16px; text-align: center; margin-bottom: 10px;">¡Es hora de tomar su medicina!</p>
                                    <button class="btn-primary" style="width: 100%; background: #10b981;" onclick="window.markTaken(${m.id})">YA LO TOMÉ</button>
                                </div>
                            ` : ''}
                        </div>
                    `}).join('')}
                </div>
                ${data.meds.length === 0 ? '<p style="margin-top: 30px; opacity: 0.6;">No hay recordatorios activos.</p>' : ''}
            </div>
            <div id="applause-container" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; pointer-events:none; z-index:9999; align-items:center; justify-content:center;">
                <div style="font-size: 80px; animation: bounce 1s infinite;">👏🎉👏</div>
            </div>
        `;
    }

    window.markTaken = (id) => {
        // Show applause animation
        const applause = document.getElementById('applause-container');
        if (applause) {
            applause.style.display = 'flex';
            setTimeout(() => {
                applause.style.display = 'none';
                // In a real app we'd update the last taken time here
                // For now just reload to recalculate
                alert("¡Excelente! Su registro ha sido guardado.");
                const data = getPatientData(selectedPatientQSL);
                loadSection('reminders');
            }, 3000);
        }
    };

    function isDoseDue(startTime, freq) {
        if (!startTime || !freq) return false;
        try {
            const now = new Date();
            const [h, m] = startTime.split(':');
            let next = new Date(now.getFullYear(), now.getMonth(), now.getDate(), parseInt(h), parseInt(m));
            const freqMs = parseInt(freq) * 3600000;

            // If the start time is in the future today, it's not due yet
            if (next > now && next.getTime() - now.getTime() > freqMs) {
                return false;
            }

            while (next <= now) { next = new Date(next.getTime() + freqMs); }

            // Check if it's within 30 minutes of the dose time (before or after)
            const timeDiff = Math.abs(next.getTime() - freqMs - now.getTime());
            return timeDiff <= 1800000; // 30 minutes in ms
        } catch (e) { return false; }
    }

    function renderSettings() {
        const isDoc = userRole === 'medico';
        contentArea.innerHTML = `
            <div class="widget-card animate-in" style="max-width: 500px; margin: 0 auto;">
                <h3 class="widget-title">Datos del Médico</h3>
                <div class="input-group" style="margin-bottom: 20px;">
                    <label>Nombre Maestro (Médico)</label>
                    <input type="text" id="new-doc-name" value="${isDoc ? localStorage.getItem('doctor_master_name') : ''}" ${!isDoc ? 'disabled' : ''}>
                </div>
                <div class="input-group" style="margin-bottom: 20px;">
                    <label>Nueva Clave de Acceso</label>
                    <input type="password" id="new-doc-pass" placeholder="Ingresar nueva clave..." ${!isDoc ? 'disabled' : ''}>
                </div>
                ${isDoc ? `
                    <button class="btn-primary" style="width: 100%; margin-bottom: 20px;" onclick="window.updateDocProfile()">GUARDAR CAMBIOS DE ACCESO</button>
                ` : '<p style="font-size: 11px; color: var(--text-muted);">Los pacientes gestionan su perfil mediante su código QSL único.</p>'}
                <hr style="border:0; border-top: 1px solid var(--card-border); margin: 20px 0;">
                <button class="btn-primary" style="width: 100%; background: var(--error);" onclick="localStorage.removeItem('user_qsl_code'); window.location.href='index.html';">CERRAR SESIÓN</button>
            </div>
        `;
    }

    window.updateDocProfile = () => {
        const name = document.getElementById('new-doc-name').value.trim();
        const pass = document.getElementById('new-doc-pass').value.trim();
        if (name) {
            localStorage.setItem('doctor_master_name', name);
            localStorage.setItem('user_real_name', name);
            if (pass) {
                localStorage.setItem('doctor_master_pass', btoa(pass));
                alert('Nombre y Clave actualizados. Se aplicarán la próxima vez que ingrese.');
            } else {
                alert('Nombre actualizado.');
            }
            updateUserDisplay();
        }
    };

    // --- UTILIDADES ---
    function calculateNextDose(startTime, freq) {
        if (!startTime || !freq) return '--:--';
        try {
            const now = new Date();
            const [h, m] = startTime.split(':');
            let next = new Date(now.getFullYear(), now.getMonth(), now.getDate(), parseInt(h), parseInt(m));
            const freqMs = parseInt(freq) * 3600000;
            while (next <= now) { next = new Date(next.getTime() + freqMs); }
            return next.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } catch (e) { return '--:--'; }
    }

    function getSectionTitle(name) {
        const titles = { overview: 'Expediente', reminders: 'Seguimiento', settings: 'Datos del Médico' };
        return titles[name] || 'H-Control';
    }

    function updateDate() {
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        dateDisplay.textContent = new Date().toLocaleDateString('es-ES', options);
    }
});
