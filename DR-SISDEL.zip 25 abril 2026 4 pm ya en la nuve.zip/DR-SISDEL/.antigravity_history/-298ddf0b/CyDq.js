document.addEventListener('DOMContentLoaded', () => {
    // 1. Verificar Acceso
    const qslCode = localStorage.getItem('user_qsl_code');
    if (!qslCode) {
        window.location.href = 'index.html';
        return;
    }

    // 2. Referencias UI
    const qslDisplay = document.getElementById('display-qsl');
    const logoutBtn = document.getElementById('logout-btn');
    const contentArea = document.getElementById('content-area');
    const sectionTitle = document.getElementById('section-title');
    const navItems = document.querySelectorAll('.nav-links li[data-section]');
    const dateDisplay = document.getElementById('current-date');

    // 3. Inicialización
    qslDisplay.textContent = `QSL: ${qslCode}`;
    updateDate();
    loadSection('overview');

    // 4. Manejo de Navegación
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');

            // Actualizar UI de navegación
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            loadSection(section);
        });
    });

    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('user_qsl_code');
        window.location.href = 'index.html';
    });

    // 5. Motor de Secciones (Fácil de Ampliar)
    function loadSection(sectionName) {
        sectionTitle.textContent = getSectionTitle(sectionName);

        // Simular carga con spinner
        contentArea.innerHTML = `
            <div class="loading-state">
                <div class="spinner"></div>
            </div>
        `;

        setTimeout(() => {
            renderSection(sectionName);
        }, 300);
    }

    function renderSection(name) {
        switch (name) {
            case 'overview':
                contentArea.innerHTML = `
                    <div class="dashboard-grid">
                        <div class="widget-card animate-in">
                            <h3 class="widget-title">Próximas Tomas</h3>
                            <ul class="med-list">
                                <li class="med-item">
                                    <div class="med-info">
                                        <h4>Paracetamol 500mg</h4>
                                        <p>Hoy - 14:00 PM</p>
                                    </div>
                                    <span class="status-badge">Pendiente</span>
                                </li>
                                <li class="med-item">
                                    <div class="med-info">
                                        <h4>Vitamina C</h4>
                                        <p>Hoy - 20:00 PM</p>
                                    </div>
                                    <span class="status-badge">Próximamente</span>
                                </li>
                            </ul>
                        </div>
                        <div class="widget-card animate-in" style="animation-delay: 0.1s">
                            <h3 class="widget-title">Estado de Salud</h3>
                            <div class="health-stats">
                                <p style="color: var(--text-muted)">No hay registros recientes de presión arterial o glucosa.</p>
                                <button class="btn-primary" style="padding: 10px; font-size: 13px; margin-top: 20px;">
                                    Agregar Registro
                                </button>
                            </div>
                        </div>
                    </div>
                `;
                break;

            case 'medications':
                contentArea.innerHTML = `
                    <div class="widget-card animate-in" style="max-width: 600px">
                        <h3 class="widget-title">Gestión de Medicamentos</h3>
                        <p style="margin-bottom: 20px; color: var(--text-muted)">Aquí podrás agregar y ver tus medicamentos actuales.</p>
                        <button class="btn-primary">Añadir Nuevo Medicamento</button>
                    </div>
                `;
                break;

            case 'reminders':
                contentArea.innerHTML = `
                    <div class="widget-card animate-in">
                        <h3 class="widget-title">Configurar Recordatorios</h3>
                        <p>Módulo en desarrollo...</p>
                    </div>
                `;
                break;

            case 'settings':
                contentArea.innerHTML = `
                    <div class="widget-card animate-in">
                        <h3 class="widget-title">Configuración</h3>
                        <p>Personaliza tu experiencia y notificaciones.</p>
                    </div>
                `;
                break;

            default:
                contentArea.innerHTML = `<p>Sección no encontrada.</p>`;
        }
    }

    function getSectionTitle(name) {
        const titles = {
            'overview': 'Resumen de Salud',
            'medications': 'Mis Medicamentos',
            'reminders': 'Alarmas y Recordatorios',
            'settings': 'Configuración'
        };
        return titles[name] || 'Control de Salud';
    }

    function updateDate() {
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        dateDisplay.textContent = new Date().toLocaleDateString('es-ES', options);
    }
});
