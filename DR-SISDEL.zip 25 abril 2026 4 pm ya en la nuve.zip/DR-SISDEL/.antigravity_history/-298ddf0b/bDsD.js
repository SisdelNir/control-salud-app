document.addEventListener('DOMContentLoaded', () => {
    // 1. Verificar Acceso y Rol
    const qslCode = localStorage.getItem('user_qsl_code');
    const userRole = localStorage.getItem('user_role');
    const userRealName = localStorage.getItem('user_real_name');

    if (!qslCode || !userRole) {
        window.location.href = 'index.html';
        return;
    }

    // 2. Referencias UI
    const qslDisplay = document.getElementById('display-qsl');
    const logoutBtn = document.getElementById('logout-btn');
    const contentArea = document.getElementById('content-area');
    const sectionTitle = document.getElementById('section-title');
    const navItems = document.querySelectorAll('.nav-links li[data-section]');
    const dateDisplay = document.getElementById('current-date');

    // Estado local
    let selectedPatientQSL = userRole === 'paciente' ? qslCode : null;

    // 3. Inicialización
    updateUserDisplay();
    updateDate();
    loadSection('overview');

    function updateUserDisplay() {
        const name = localStorage.getItem('user_real_name') || qslCode;
        qslDisplay.textContent = userRole === 'medico' ? `Dr. ${name}` : `Paciente: ${name}`;
    }

    // 4. Navegación
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            loadSection(section);
        });
    });

    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('user_qsl_code');
        localStorage.removeItem('user_role');
        window.location.href = 'index.html';
    });

    // 5. Motor de Datos
    function getStorageKey(suffix) {
        return `health_${selectedPatientQSL}_${suffix}`;
    }

    function getMedications() {
        if (!selectedPatientQSL) return [];
        const meds = localStorage.getItem(getStorageKey('meds'));
        return meds ? JSON.parse(meds) : [];
    }

    function saveMedication(med) {
        const meds = getMedications();
        meds.push({ ...med, id: Date.now() });
        localStorage.setItem(getStorageKey('meds'), JSON.stringify(meds));
    }

    // 6. Motor de Secciones
    function loadSection(sectionName) {
        sectionTitle.textContent = getSectionTitle(sectionName);
        contentArea.innerHTML = `<div class="loading-state"><div class="spinner"></div></div>`;
        setTimeout(() => renderSection(sectionName), 300);
    }

    function renderSection(name) {
        if (userRole === 'medico' && !selectedPatientQSL && name !== 'settings') {
            renderPatientSearch();
            return;
        }

        const medications = getMedications();

        switch (name) {
            case 'overview': renderOverview(medications); break;
            case 'medications': renderMedications(medications); break;
            case 'reminders': renderReminders(medications); break;
            case 'settings': renderSettings(); break;
        }
    }

    // --- FUNCIONES DE RENDERIZADO ---

    function renderPatientSearch() {
        contentArea.innerHTML = `
            <div class="widget-card animate-in" style="max-width: 500px; margin: 40px auto; text-align: center;">
                <h3 class="widget-title">Buscador de Pacientes</h3>
                <p style="margin-bottom: 25px; color: var(--text-muted)">Ingrese el QSL del paciente para acceder a su expediente clínico.</p>
                <div class="input-group" style="margin-bottom: 20px;">
                    <input type="text" id="search-qsl" placeholder="Ej: QSL-XP-100" style="text-align: center; text-transform: uppercase;">
                </div>
                <button id="btn-search-patient" class="btn-primary" style="width: 100%">
                    <span>Cargar Expediente</span>
                </button>
            </div>
        `;
        document.getElementById('btn-search-patient').onclick = () => {
            const val = document.getElementById('search-qsl').value.trim().toUpperCase();
            if (val) {
                selectedPatientQSL = val;
                loadSection('overview');
            }
        };
    }

    function renderOverview(meds) {
        const patientName = localStorage.getItem(`patient_name_${selectedPatientQSL}`) || selectedPatientQSL;
        contentArea.innerHTML = `
            <div class="dashboard-grid">
                <div class="widget-card animate-in">
                    <h3 class="widget-title">Expediente: ${patientName}</h3>
                    <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 20px;">QSL: ${selectedPatientQSL}</p>
                    
                    <h4 style="margin-bottom: 15px; font-size: 14px; text-transform: uppercase; letter-spacing:1px;">Cronograma de Hoy</h4>
                    <div class="med-list">
                        ${meds.length > 0 ? meds.map(m => {
            const next = calculateNextDose(m.startTime, m.frequency);
            return `
                                <div class="med-item" style="padding: 15px; background: rgba(255,255,255,0.02); border-radius: 12px; margin-bottom: 10px;">
                                    <div class="med-info">
                                        <h4 style="color: var(--accent)">${m.name}</h4>
                                        <p style="font-size: 13px;">Dosis: ${m.dose} | Próxima: <strong>${next}</strong></p>
                                    </div>
                                </div>
                            `;
        }).join('') : '<p style="color: var(--text-muted)">No hay medicación programada.</p>'}
                    </div>
                </div>
                
                <div class="widget-card animate-in" style="animation-delay: 0.1s">
                    <h3 class="widget-title">Resumen de Seguimiento</h3>
                    <div style="display: flex; flex-direction: column; gap: 12px;">
                        <div style="display: flex; justify-content: space-between;">
                            <span style="color: var(--text-muted)">Medicamentos Activos</span>
                            <span style="color: var(--accent); font-weight: 600;">${meds.length}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span style="color: var(--text-muted)">Estado del Tratamiento</span>
                            <span style="color: #10b981;">Normal</span>
                        </div>
                        <hr style="border: 0; border-top: 1px solid var(--card-border); margin: 5px 0;">
                        ${userRole === 'medico' ? `
                            <button class="btn-primary" style="width: 100%" onclick="selectedPatientQSL=null; loadSection('overview')">Gestionar otro Paciente</button>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }

    function renderMedications(meds) {
        const patientName = localStorage.getItem(`patient_name_${selectedPatientQSL}`) || selectedPatientQSL;
        contentArea.innerHTML = `
            <div class="widget-card animate-in">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                    <div>
                        <h3 class="widget-title">Módulo de Medicación</h3>
                        <p style="font-size: 13px; color: var(--text-muted)">Paciente: ${patientName}</p>
                    </div>
                    ${userRole === 'medico' ? `
                        <button id="add-med-btn" class="btn-primary" style="padding: 8px 16px; font-size: 13px;">+ Prescribir</button>
                    ` : ''}
                </div>

                <div id="med-form-container" style="display: none; margin-bottom: 30px; padding: 25px; background: rgba(0,0,0,0.3); border: 1px solid var(--card-border); border-radius: 20px;">
                    <h4 style="margin-bottom: 20px; color: var(--accent); font-size: 14px; text-transform: uppercase;">Nueva Prescripción</h4>
                    <div class="dashboard-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                        <div class="input-group">
                            <label>Nombre del Medicamento</label>
                            <input type="text" id="m-name" placeholder="Ej: Amoxicilina">
                        </div>
                        <div class="input-group">
                            <label>Dosis / Presentación</label>
                            <input type="text" id="m-dose" placeholder="Ej: 500mg">
                        </div>
                        <div class="input-group">
                            <label>Frecuencia (Horas)</label>
                            <input type="number" id="m-freq" placeholder="Cada X horas">
                        </div>
                        <div class="input-group">
                            <label>Hora Inicio (1ra toma)</label>
                            <input type="time" id="m-start" value="08:00">
                        </div>
                        <div class="input-group">
                            <label>Duración (Días)</label>
                            <input type="number" id="m-days" placeholder="Días totales">
                        </div>
                    </div>
                    <div class="input-group" style="margin-top: 15px;">
                        <label>Notas e Instrucciones</label>
                        <input type="text" id="m-notes" placeholder="Ej: Tomar con alimentos">
                    </div>
                    <div style="display: flex; gap: 10px; margin-top: 25px;">
                        <button id="btn-save-medication" class="btn-primary" style="flex: 2;">
                            <span>GUARDAR MEDICAMENTO</span>
                        </button>
                        <button id="btn-cancel-medication" class="btn-primary" style="flex: 1; background: transparent; border: 1px solid var(--card-border);">CANCELAR</button>
                    </div>
                </div>

                <div class="med-list-container">
                    ${meds.length > 0 ? meds.map(m => `
                        <div class="widget-card" style="margin-bottom: 15px; background: rgba(255,255,255,0.03); border-color: rgba(255,255,255,0.05);">
                            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                                <div class="med-info">
                                    <h4 style="font-size: 16px;">${m.name} <span style="color: var(--accent); font-weight: 400;">(${m.dose})</span></h4>
                                    <p style="margin: 8px 0; font-size: 13px; color: var(--text-muted);">
                                        <strong>Horario:</strong> Cada ${m.frequency}h | <strong>Inicio:</strong> ${m.startTime} | <strong>Duración:</strong> ${m.days} días
                                    </p>
                                    <p style="font-size: 12px; font-style: italic; opacity: 0.8;">"${m.notes || 'Sin instrucciones'}"</p>
                                </div>
                                <div style="display: flex; flex-direction: column; gap: 8px; align-items: flex-end;">
                                    <span class="status-badge" style="background: rgba(34, 211, 238, 0.1);">Vigente</span>
                                    ${userRole === 'medico' ? `
                                        <button class="status-badge" style="background: rgba(239, 68, 68, 0.1); color: var(--error); border: none; cursor: pointer;" onclick="window.removeMed(${m.id})">ELIMINAR</button>
                                    ` : ''}
                                </div>
                            </div>
                        </div>
                    `).join('') : '<div style="text-align: center; padding: 40px; color: var(--text-muted);">No hay medicamentos vigentes registrados.</div>'}
                </div>
            </div>
        `;

        if (userRole === 'medico') {
            document.getElementById('add-med-btn').onclick = () => {
                document.getElementById('med-form-container').style.display = 'block';
                document.getElementById('add-med-btn').style.display = 'none';
            };
            document.getElementById('btn-cancel-medication').onclick = () => {
                document.getElementById('med-form-container').style.display = 'none';
                document.getElementById('add-med-btn').style.display = 'block';
            };
            document.getElementById('btn-save-medication').onclick = () => {
                const med = {
                    name: document.getElementById('m-name').value,
                    dose: document.getElementById('m-dose').value,
                    frequency: document.getElementById('m-freq').value,
                    startTime: document.getElementById('m-start').value,
                    days: document.getElementById('m-days').value,
                    notes: document.getElementById('m-notes').value
                };
                if (med.name && med.dose && med.frequency) {
                    saveMedication(med);
                    loadSection('medications');
                } else { alert('Por favor complete los campos obligatorios.'); }
            };
        }
    }

    function renderReminders(meds) {
        contentArea.innerHTML = `
            <div class="widget-card animate-in" style="text-align: center;">
                <h3 class="widget-title">Sistema de Alertas</h3>
                <p style="color: var(--text-muted); margin-bottom: 30px;">Las notificaciones se activan automáticamente según la frecuencia programada.</p>
                <div class="dashboard-grid">
                    ${meds.length > 0 ? meds.map(m => `
                        <div class="widget-card" style="background: rgba(0,0,0,0.2); text-align: left;">
                            <h4 style="color: var(--accent); margin-bottom: 10px;">${m.name}</h4>
                            <p style="font-size: 13px;">Próximo aviso a las: <strong>${calculateNextDose(m.startTime, m.frequency)}</strong></p>
                        </div>
                    `).join('') : '<p>No hay alarmas activas.</p>'}
                </div>
            </div>
        `;
    }

    function renderSettings() {
        contentArea.innerHTML = `
            <div class="widget-card animate-in" style="max-width: 600px; margin: 0 auto;">
                <h3 class="widget-title">Configuración del Sistema</h3>
                <div style="display: flex; flex-direction: column; gap: 25px;">
                    
                    <div class="settings-group">
                        <h4 style="margin-bottom: 15px; font-size: 14px; color: var(--accent);">MI PERFIL</h4>
                        <div class="input-group" style="margin-bottom: 10px;">
                            <label>Nombre Mostrado</label>
                            <input type="text" id="set-name" value="${localStorage.getItem('user_real_name') || ''}">
                        </div>
                        <button id="btn-save-name" class="btn-primary" style="font-size: 12px; padding: 10px;">
                            <span>GUARDAR NOMBRE</span>
                        </button>
                    </div>

                    <div class="settings-group">
                        <h4 style="margin-bottom: 15px; font-size: 14px; color: var(--accent);">SEGURIDAD</h4>
                        <div class="input-group" style="margin-bottom: 10px;">
                            <label>Cambiar Código de Acceso (QSL/ID)</label>
                            <input type="text" id="set-qsl" value="${qslCode}" style="text-transform: uppercase;">
                        </div>
                        <p style="font-size: 11px; color: var(--text-muted); margin-bottom: 10px;">El código se guarda de forma encriptada en la sesión.</p>
                        <button id="btn-save-qsl" class="btn-primary" style="font-size: 12px; padding: 10px; background: var(--primary-hover);">
                            <span>ACTUALIZAR CÓDIGO DE ACCESO</span>
                        </button>
                    </div>

                    ${userRole === 'medico' ? `
                    <div class="settings-group" style="padding-top: 20px; border-top: 1px solid var(--card-border);">
                        <h4 style="margin-bottom: 15px; font-size: 14px; color: var(--accent);">VISTA DE PACIENTE</h4>
                        <p style="font-size: 12px; color: var(--text-muted); margin-bottom: 15px;">
                            Puede previsualizar exactamente lo que ve su paciente ingresando su QSL.
                        </p>
                        <button class="btn-primary" onclick="alert('Como médico, use el buscador de pacientes en la pantalla principal para ver y gestionar los medicamentos de cada paciente.'); loadSection('overview');" style="background: rgba(255,255,255,0.05); color: var(--text-main);">
                            <span>COMPROBAR VISTA DE PACIENTE</span>
                        </button>
                    </div>
                    ` : ''}

                    <div class="settings-group" style="margin-top: 20px; padding-top: 20px; border-top: 1px solid var(--card-border);">
                        <button class="btn-primary" onclick="localStorage.clear(); window.location.href='index.html';" style="background: var(--error); width: 100%;">
                            CERRAR SESIÓN Y BORRAR TODO
                        </button>
                    </div>
                </div>
            </div>
        `;

        document.getElementById('btn-save-name').onclick = () => {
            const newName = document.getElementById('set-name').value.trim();
            if (newName) {
                localStorage.setItem('user_real_name', newName);
                if (userRole === 'paciente') localStorage.setItem(`patient_name_${qslCode}`, newName);
                else localStorage.setItem(`doctor_name_${qslCode}`, newName);
                updateUserDisplay();
                alert('Nombre guardado correctamente.');
            }
        };

        document.getElementById('btn-save-qsl').onclick = () => {
            const newQsl = document.getElementById('set-qsl').value.trim().toUpperCase();
            if (newQsl && newQsl.length >= 3) {
                localStorage.setItem('user_qsl_code', newQsl);
                localStorage.setItem('user_qsl_auth', btoa(newQsl)); // Encriptado Base64
                window.location.reload();
            } else { alert('El código debe tener al menos 3 caracteres.'); }
        };
    }

    // --- UTILIDADES ---

    window.removeMed = (id) => {
        if (confirm('¿Desea eliminar esta medicación?')) {
            const meds = getMedications().filter(m => m.id !== id);
            localStorage.setItem(getStorageKey('meds'), JSON.stringify(meds));
            loadSection('medications');
        }
    };

    function calculateNextDose(startTime, freq) {
        if (!startTime || !freq) return '--:--';
        try {
            const now = new Date();
            const [h, m] = startTime.split(':');
            let next = new Date(now.getFullYear(), now.getMonth(), now.getDate(), parseInt(h), parseInt(m));
            const freqMs = parseInt(freq) * 3600000;

            while (next <= now) { next = new Date(next.getTime() + freqMs); }
            return next.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } catch (e) { return '--:--'; }
    }

    function getSectionTitle(name) {
        const titles = { overview: 'Resumen Diario', medications: 'Plan Médico', reminders: 'Alertas', settings: 'Configuración' };
        return titles[name] || 'H-Control';
    }

    function updateDate() {
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        dateDisplay.textContent = new Date().toLocaleDateString('es-ES', options);
    }
});
