# UI Redesign for Adults Implementation Plan

This plan aims to address the user's request for a clear, elegant design with larger fonts, specifically targeting the login screen and sidebar as shown in the screenshots, but applying the principles globally.

## Proposed Changes

### CSS Variables & Base Styles (`style.css`)
- **Color Palette Update:** Shift from the dark, slightly muted slate theme to a clearer, more elegant contrast. Consider a deep sapphire blue background with bright, clear white text and a striking accent color (like a vibrant teal or elegant gold) to replace the current purple/blue gradients.
- **Base Font Size:** Increase the base font size on the `body` or `:root` to ensure all relative units (`em`, `rem`) scale up properly.
- **Input Fields:** Make input fields stand out more by giving them a slightly lighter background (e.g., `rgba(255,255,255,0.1)`) instead of the current very dark one, and increase the placeholder font size.
- **Role Buttons (Login):** Increase the padding and icon size of the "Paciente" and "Medico" buttons on the login screen. Make the active state more pronounced.

### Sidebar UI (`dashboard.css`)
- **Sidebar Background:** Lighten the sidebar slightly or give it a distinct border to separate it clearly from the main content.
- **Navigation Links:** Increase the font size and padding of the navigation items. Make the icons larger.
- **User Info Section:** Enhance the visibility of the "CERRAR SESIÓN" button added previously, ensuring its colors fit the new elegant theme while remaining obvious.

### Patient Form UI (`dashboard.css` & `dashboard.html`)
- **Dark Neon Aesthetic:** Apply the aesthetic from the provided screenshot. The background of the form cards will be very dark (almost black, e.g., `rgba(10, 15, 30, 0.95)`).
- **Glowing Borders:** Add subtle glowing borders to different sections or input fields (e.g., green for vital signs, blue for general data, orange for alerts) using `box-shadow` and thin `border`.
- **Large Typography:** Use large, bold, stark white text for primary values/inputs, and bright colored uppercase text for labels (like "RITMO", "PRESIÓN").
- **Card Layout:** Instead of one large flat form, split the patient data into distinct "cards" inside the grid, similar to the "Estado en Tiempo Real" widgets.
- **Icons & Indicators:** Incorporate small glowing dots and icons next to labels to mimic the executive dashboard look.

## Verification Plan

- [ ] Check the login screen (index.html) to ensure the role buttons, inputs, and the "Iniciar Sesión" button are large, clear, and elegant.
- [ ] Check the dashboard (dashboard.html) to ensure the sidebar links and user info section are easy to read.
- [ ] Ensure the overall contrast is high enough for older adults to read comfortably without straining.
