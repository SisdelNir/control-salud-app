/**
 * LexControl - Logic & State Management
 */

// --- STATE ---
let state = {
    cases: JSON.parse(localStorage.getItem('lexcontrol_cases')) || [],
    currentView: 'dashboard',
    theme: localStorage.getItem('lexcontrol_theme') || 'light',
    user: JSON.parse(localStorage.getItem('lexcontrol_user')) || { username: 'ABOGADOS', password: 'JUSTICIA' },
    isLoggedIn: false
};

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    renderView();
    setupEventListeners();
    updateStats();
});

// --- THEME ---
function initTheme() {
    document.documentElement.setAttribute('data-theme', state.theme);
    const themeBtn = document.getElementById('theme-toggle');
    updateThemeUI(themeBtn);
}

function toggleTheme() {
    state.theme = state.theme === 'light' ? 'dark' : 'light';
    localStorage.setItem('lexcontrol_theme', state.theme);
    document.documentElement.setAttribute('data-theme', state.theme);
    updateThemeUI(document.getElementById('theme-toggle'));
}

function updateThemeUI(btn) {
    const icon = btn.querySelector('i');
    const text = btn.querySelector('span');
    if (state.theme === 'dark') {
        icon.setAttribute('data-lucide', 'moon');
        text.textContent = 'Modo Oscuro';
    } else {
        icon.setAttribute('data-lucide', 'sun');
        text.textContent = 'Modo Claro';
    }
    lucide.createIcons();
}

// --- VIEW RENDERING ---
function renderView() {
    const contentArea = document.getElementById('content-view');
    contentArea.innerHTML = '';

    switch (state.currentView) {
        case 'dashboard':
            renderDashboard(contentArea);
            break;
        case 'clients':
            renderClients(contentArea);
            break;
        case 'payments':
            renderPayments(contentArea);
            break;
        case 'config':
            renderConfig(contentArea);
            break;
        default:
            renderDashboard(contentArea);
    }
    lucide.createIcons();
}

function renderDashboard(container) {
    container.innerHTML = `
        <div class="view-header">
            <h1>Panel de Control</h1>
            <p class="text-muted">Resumen general de tu bufete</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Casos Activos</h3>
                <p id="stat-active-cases">0</p>
            </div>
            <div class="stat-card">
                <h3>Total por Cobrar</h3>
                <p id="stat-total-balance">Q 0.00</p>
            </div>
            <div class="stat-card">
                <h3>Próximos Vencimientos</h3>
                <p id="stat-reminders">0</p>
            </div>
        </div>

        <div class="recent-cases">
            <div class="view-header">
                <h2>Casos Recientes</h2>
            </div>
            <div class="data-table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Expediente</th>
                            <th>Cliente</th>
                            <th>Asunto</th>
                            <th>Estado</th>
                            <th>Saldo</th>
                        </tr>
                    </thead>
                    <tbody id="recent-cases-list">
                        <!-- Items injected here -->
                    </tbody>
                </table>
            </div>
        </div>
    `;
    updateDashboardStats();
    renderRecentCases();
}

function renderClients(container) {
    container.innerHTML = `
        <div class="view-header">
            <h1>Clientes y Casos</h1>
            <button class="btn btn-primary" onclick="openModal()">
                <i data-lucide="plus"></i> Nuevo Registro
            </button>
        </div>
        <div class="data-table-container">
            <table>
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Cliente</th>
                        <th>Expediente / Asunto</th>
                        <th>Teléfono</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="full-case-list">
                    <!-- Items injected here -->
                </tbody>
            </table>
        </div>
    `;
    renderFullCaseList();
}

function renderPayments(container) {
    container.innerHTML = `
        <div class="view-header">
            <h1>Control de Pagos</h1>
        </div>
        <div class="data-table-container">
            <table>
                <thead>
                    <tr>
                        <th>Cliente</th>
                        <th>Servicio</th>
                        <th>Total</th>
                        <th>Pagado</th>
                        <th>Saldo</th>
                        <th>Próximo Pago</th>
                    </tr>
                </thead>
                <tbody id="payments-list">
                    <!-- Items injected here -->
                </tbody>
            </table>
        </div>
    `;
    renderPaymentsList();
}

function renderConfig(container) {
    container.innerHTML = `
        <div class="view-header">
            <h1>Configuración del Sistema</h1>
        </div>
        
        <div class="config-card">
            <div class="config-section">
                <h2>Seguridad y Acceso</h2>
                <p>Cambie su nombre de usuario y contraseña para acceder al sistema.</p>
                
                <form id="config-auth-form" class="form-grid">
                    <div class="form-group">
                        <label>Nuevo Usuario</label>
                        <input type="text" id="conf-username" value="${state.user.username}" required>
                    </div>
                    <div class="form-group">
                        <label>Nueva Contraseña</label>
                        <input type="password" id="conf-password" value="${state.user.password}" required>
                    </div>
                    <div class="full-width">
                        <button type="submit" class="btn btn-primary">Actualizar Credenciales</button>
                    </div>
                </form>
            </div>

            <div class="config-section">
                <h2>Base de Datos</h2>
                <p>Gestión de la información almacenada localmente.</p>
                <button class="btn btn-secondary" onclick="exportData()">
                    <i data-lucide="download"></i> Exportar Datos (JSON)
                </button>
                <button class="btn btn-secondary" style="color: #ef4444; border-color: #ef4444;" onclick="resetSystem()">
                    <i data-lucide="trash-2"></i> Reiniciar Sistema
                </button>
            </div>
        </div>
    `;
    setupConfigEvents();
    lucide.createIcons();
}

// --- DATA LIST RENDERING ---
function renderRecentCases() {
    const list = document.getElementById('recent-cases-list');
    if (!list) return;

    const recent = [...state.cases].reverse().slice(0, 5);
    if (recent.length === 0) {
        list.innerHTML = '<tr><td colspan="5" style="text-align:center; padding: 40px; color: #94a3b8;">No hay casos registrados aún</td></tr>';
        return;
    }

    list.innerHTML = recent.map(c => `
        <tr>
            <td><strong>${c.numeroExpediente || 'N/A'}</strong></td>
            <td>${c.nombreCliente}</td>
            <td>${c.casoAsunto}</td>
            <td><span class="badge ${getStatusBadgeClass(c.estadoCaso)}">${c.estadoCaso}</span></td>
            <td>Q ${parseFloat(c.saldo).toFixed(2)}</td>
        </tr>
    `).join('');
}

function renderFullCaseList() {
    const list = document.getElementById('full-case-list');
    if (!list) return;

    if (state.cases.length === 0) {
        list.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 40px; color: #94a3b8;">No hay datos disponibles</td></tr>';
        return;
    }

    list.innerHTML = state.cases.map((c, index) => `
        <tr>
            <td>${c.fechaRegistro}</td>
            <td><strong>${c.nombreCliente}</strong><br><small>${c.nitCui || ''}</small></td>
            <td><strong>${c.numeroExpediente || 'S/E'}</strong><br>${c.casoAsunto}</td>
            <td>${c.telefono || '---'}</td>
            <td><span class="badge ${getStatusBadgeClass(c.estadoCaso)}">${c.estadoCaso}</span></td>
            <td>
                <button class="btn-close" onclick="deleteCase(${index})"><i data-lucide="trash-2"></i></button>
            </td>
        </tr>
    `).join('');
    lucide.createIcons();
}

function renderPaymentsList() {
    const list = document.getElementById('payments-list');
    if (!list) return;

    list.innerHTML = state.cases.map(c => `
        <tr>
            <td><strong>${c.nombreCliente}</strong></td>
            <td>${c.descripcionServicio || '---'}</td>
            <td>Q ${parseFloat(c.totalPagar).toFixed(2)}</td>
            <td>Q ${parseFloat(c.pagoRealizado).toFixed(2)}</td>
            <td style="color: ${c.saldo > 0 ? '#ef4444' : '#10b981'}; font-weight: 600;">Q ${parseFloat(c.saldo).toFixed(2)}</td>
            <td>${c.fechaProximoPago || '---'}</td>
        </tr>
    `).join('');
}

function getStatusBadgeClass(status) {
    switch (status) {
        case 'Activo': return 'badge-active';
        case 'En trámite': return 'badge-pending';
        case 'Resuelto': return 'badge-resolved';
        case 'Archivado': return 'badge-pending';
        default: return '';
    }
}

// --- STATS ---
function updateDashboardStats() {
    const activeCases = state.cases.filter(c => c.estadoCaso === 'Activo' || c.estadoCaso === 'En trámite').length;
    const totalBalance = state.cases.reduce((sum, c) => sum + parseFloat(c.saldo || 0), 0);
    const activeReminders = state.cases.filter(c => c.recordatorioActivo).length;

    const elActive = document.getElementById('stat-active-cases');
    const elBalance = document.getElementById('stat-total-balance');
    const elReminders = document.getElementById('stat-reminders');

    if (elActive) elActive.textContent = activeCases;
    if (elBalance) elBalance.textContent = `Q ${totalBalance.toLocaleString('es-GT', { minimumFractionDigits: 2 })}`;
    if (elReminders) elReminders.textContent = activeReminders;
}

function updateStats() {
    if (state.currentView === 'dashboard') updateDashboardStats();
}

// --- MODAL & FORM ---
function openModal() {
    document.getElementById('modal-container').classList.remove('hidden');
    document.getElementById('fechaRegistro').valueAsDate = new Date();
}

function closeModal() {
    document.getElementById('modal-container').classList.add('hidden');
    document.getElementById('case-form').reset();
    switchTab('tab-a');
}

function setupEventListeners() {
    // Login Handling
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const userIn = document.getElementById('login-username').value;
            const passIn = document.getElementById('login-password').value;

            if (userIn === state.user.username && passIn === state.user.password) {
                state.isLoggedIn = true;
                document.getElementById('login-screen').classList.add('hidden');
                document.getElementById('app').classList.remove('hidden');
                renderView();
            } else {
                alert('Usuario o contraseña incorrectos');
            }
        });
    }

    // Nav
    document.getElementById('nav-dashboard').addEventListener('click', () => switchView('dashboard'));
    document.getElementById('nav-clients').addEventListener('click', () => switchView('clients'));
    document.getElementById('nav-payments').addEventListener('click', () => switchView('payments'));
    document.getElementById('nav-calendar').addEventListener('click', () => switchView('clients'));
    document.getElementById('nav-config').addEventListener('click', () => switchView('config'));

    // Actions
    document.getElementById('btn-new-case').addEventListener('click', openModal);
    document.getElementById('close-modal').addEventListener('click', closeModal);
    document.getElementById('cancel-form').addEventListener('click', closeModal);
    document.getElementById('theme-toggle').addEventListener('click', toggleTheme);

    // Form logic
    const totalInput = document.getElementById('totalPagar');
    const payInput = document.getElementById('pagoRealizado');
    const saldoInput = document.getElementById('saldo');

    const updateSaldo = () => {
        const total = parseFloat(totalInput.value) || 0;
        const paid = parseFloat(payInput.value) || 0;
        saldoInput.value = (total - paid).toFixed(2);
    };

    totalInput.addEventListener('input', updateSaldo);
    payInput.addEventListener('input', updateSaldo);

    // Tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    // Submit
    document.getElementById('case-form').addEventListener('submit', (e) => {
        e.preventDefault();
        saveCase();
    });

    // Search
    document.getElementById('global-search').addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        // Simple search logic for total cases
        if (state.currentView === 'clients') {
            const filtered = state.cases.filter(c =>
                c.nombreCliente.toLowerCase().includes(query) ||
                (c.numeroExpediente && c.numeroExpediente.toLowerCase().includes(query)) ||
                c.casoAsunto.toLowerCase().includes(query)
            );
            // Temporary override for view
            renderCaseListWithData(filtered);
        }
    });

    // Special type combo
    document.getElementById('tipoCaso').addEventListener('change', (e) => {
        const container = document.getElementById('otroTipoContainer');
        if (e.target.value === 'Otro') {
            container.classList.remove('hidden');
        } else {
            container.classList.add('hidden');
        }
    });
}

function switchTab(tabId) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tabId));
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.toggle('active', p.id === tabId));
}

function switchView(view) {
    state.currentView = view;
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.id === `nav-${view}`);
    });
    renderView();
}

function saveCase() {
    const formData = new FormData(document.getElementById('case-form'));
    const caseData = {};
    formData.forEach((value, key) => {
        caseData[key] = value;
    });

    // Handle checkboxes
    caseData.recordatorioActivo = document.getElementById('recordatorioActivo').checked;

    // Ensure numbers are numbers
    caseData.totalPagar = parseFloat(caseData.totalPagar) || 0;
    caseData.pagoRealizado = parseFloat(caseData.pagoRealizado) || 0;
    caseData.saldo = caseData.totalPagar - caseData.pagoRealizado;

    state.cases.push(caseData);
    localStorage.setItem('lexcontrol_cases', JSON.stringify(state.cases));

    closeModal();
    renderView();
    updateStats();

    // Notification (simple alert for demo, could be better)
    alert('Caso guardado con éxito');
}

function deleteCase(index) {
    if (confirm('¿Está seguro de eliminar este registro?')) {
        state.cases.splice(index, 1);
        localStorage.setItem('lexcontrol_cases', JSON.stringify(state.cases));
        renderView();
        updateStats();
    }
}

function renderCaseListWithData(data) {
    const list = document.getElementById('full-case-list');
    if (!list) return;

    list.innerHTML = data.map((c, index) => `
        <tr>
            <td>${c.fechaRegistro}</td>
            <td><strong>${c.nombreCliente}</strong><br><small>${c.nitCui || ''}</small></td>
            <td><strong>${c.numeroExpediente || 'S/E'}</strong><br>${c.casoAsunto}</td>
            <td>${c.telefono || '---'}</td>
            <td><span class="badge ${getStatusBadgeClass(c.estadoCaso)}">${c.estadoCaso}</span></td>
            <td>
                <button class="btn-close" onclick="deleteCase(${index})"><i data-lucide="trash-2"></i></button>
            </td>
        </tr>
    `).join('');
    lucide.createIcons();
}

function setupConfigEvents() {
    const form = document.getElementById('config-auth-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const newU = document.getElementById('conf-username').value;
        const newP = document.getElementById('conf-password').value;

        state.user = { username: newU, password: newP };
        localStorage.setItem('lexcontrol_user', JSON.stringify(state.user));
        alert('Credenciales actualizadas correctamente');
    });
}

function exportData() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state.cases, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "lexcontrol_export.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
}

function resetSystem() {
    if (confirm('¿DE VERDAD desea borrar todos los datos? Esta acción no se puede deshacer.')) {
        localStorage.clear();
        location.reload();
    }
}
