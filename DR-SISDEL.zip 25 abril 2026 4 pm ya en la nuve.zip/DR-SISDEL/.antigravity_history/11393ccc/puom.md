# Task: Debugging buttons in ABOGADOS app

## Plan
1. [ ] Open `index.html` in the browser.
2. [ ] Verify app load.
3. [ ] Test sidebar buttons:
    - [ ] Dashboard
    - [ ] Clientes y Casos
    - [ ] Calendario
    - [ ] Facturación
    - [ ] Documentos
    - [ ] Configuracion
4. [ ] Test "Nuevo Caso" button.
5. [ ] Check console logs for errors.
6. [ ] Report findings.

## Findings
- 
